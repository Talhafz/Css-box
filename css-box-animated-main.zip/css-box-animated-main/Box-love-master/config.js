const CONFIG = {
    titleWeb: "Gửi em",

    background: "background.jpg",

    min1: "min1.jfif",
    min2: "min2.jpg",
    min3: "max3.jpg",
    min4: "max4.webp",
    min5: "min5.jpg",
    min6: "min6.jpg",

    max1: "max1.jpg",
    max2: "max2.jpg",
    max3: "max3.jpg",
    max4: "max4.webp",
    max5: "max5.png",
    max6: "max6.jpg",
}